		<!-- START FOOTER -->
		<div class="footer_bg">
			<div class="wrap">
				<div class="footer">
					<div class="copy">
						<p class="link"><span>© All rights reserved | Designed by <a href="#"> {{OUR COMPANY}}</a></span></p>
					</div>
					<div class="f_nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="aboutus.php">About Us</a></li>
							<li><a href="privacy.html">Privacy Policy</a></li>
							<li><a href="terms.html">Terms of Use</a></li>
						</ul>
					</div>
					<div class="soc_icons">
						<ul>
							<li><a class="icon1" href="#"></a></li>
							<li><a class="icon2" href="#"></a></li>
							<li><a class="icon3" href="#"></a></li>
							<div class="clear"></div>
						</ul>	
					</div>
					<div class="clear"></div>
				</div>
			</div>
		</div>
		<!-- /END FOOTER -->